package com.example.recipify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {

    Food selectedFood;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        getSelectedFood();  //선택한 음식정보 가져옴

        setValues ();  // 정보 화면에 보여줌
    }

    private void setValues() {

        TextView tv = findViewById(R.id.food_detail_name);
        ImageView iv = findViewById(R.id.food_detail_image);

        tv.setText(selectedFood.getName());
        iv.setImageResource(selectedFood.getImage());

    }

    private void getSelectedFood() {

        Intent intent = getIntent();
        String id = intent.getStringExtra("id");

        selectedFood = MainActivity.foodsList.get(Integer.valueOf(id));
    }
}