package com.example.recipify;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    public static ArrayList<Food> foodsList = new ArrayList<Food>();

    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setUpData(); //데이터세팅

        setUpList();  //리스트 세팅

        setUpOnClickListener();  //상세 페이지 이벤트

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO); //다크모드 해제
        //로딩시간
    }

    private void setUpData() {

        Food pizza = new Food("0", "pizza", R.drawable.pizza);
        foodsList.add(pizza);
    }

    private void setUpList() {
        listView = findViewById(R.id.food_Listview);

        FoodAdapter adapter = new FoodAdapter(getApplicationContext(), 0, foodsList);
        listView.setAdapter(adapter);

    }


    private void setUpOnClickListener() {
        listView.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//@override
            public void OnItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                Food selectFood = (Food) listView.getItemAtPosition(position);
                Intent showDetail = new Intent(getApplicationContext(),DetailActivity.class);
                showDetail.putExtra("id",selectFood.getId());
                startActivity(showDetail);
            }

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){

            }
        });
    }

    private void searchFood() {

        SearchView searchView = findViewById(R.id.food_search_view);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                ArrayList<Food> filterFood = new ArrayList<Food>();
                for (int i = 0; i < foodsList.size(); i++) {
                    Food food = foodsList.get(i);
                    //데이터와 비교해서 쓴 음식 이름이 있다면
                    if (food.getName().toLowerCase().contains(newText.toLowerCase())) {

                        filterFood.add(food);
                    }
                }

                FoodAdapter adapter = new FoodAdapter(getApplicationContext(),0, filterFood);
                listView.setAdapter(adapter);
                return false;
            }
        });

    }
}